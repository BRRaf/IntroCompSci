
public enum NonCaffeinatedBeverages {
	Water, Milk, Smoothie
}
