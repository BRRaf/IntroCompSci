
public enum CaffeinatedBeverages {
	Coke, Coffee, Tea
}

